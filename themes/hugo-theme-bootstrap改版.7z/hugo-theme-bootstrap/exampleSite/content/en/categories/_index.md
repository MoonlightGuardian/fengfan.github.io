+++
title = "Categories"
[menu.main]
  weight = 20
  pre = '<i class="fas fa-fw fa-folder"></i>'
  url = "categories"
+++
