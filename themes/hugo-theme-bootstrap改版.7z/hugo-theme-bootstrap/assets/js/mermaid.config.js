// See https://mermaid-js.github.io/mermaid/#/Setup?id=configuration
window.mermaidOptions = {
    theme: 'dark',
}
